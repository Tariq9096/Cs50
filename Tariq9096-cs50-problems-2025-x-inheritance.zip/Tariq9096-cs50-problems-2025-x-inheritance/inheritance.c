// CS50 Lab: Inheritance
// Full solution you can paste into inheritance.c

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define NUM_GENERATIONS 3
#define INDENT_LENGTH 4

// Each person has two parents and two alleles
typedef struct person
{
    struct person *parents[2];
    char alleles[2];
} person;

// Function prototypes
person *create_family(int generations);
void print_family(person *p, int generation);
void free_family(person *p);
char random_allele(void);

int main(void)
{
    // Seed random number generator
    srand((unsigned) time(NULL));

    // Create a new family with NUM_GENERATIONS generations
    person *p = create_family(NUM_GENERATIONS);

    // Print family tree of blood types
    print_family(p, 0);

    // Free memory
    free_family(p);
    return 0;
}

person *create_family(int generations)
{
    // Allocate memory for new person
    person *p = malloc(sizeof(person));
    if (p == NULL)
    {
        fprintf(stderr, "Memory allocation failed\n");
        exit(1);
    }

    // Base case: no parents (oldest generation)
    if (generations <= 1)
    {
        p->parents[0] = NULL;
        p->parents[1] = NULL;
        p->alleles[0] = random_allele();
        p->alleles[1] = random_allele();
        return p;
    }

    // Recursive case: create two parents
    p->parents[0] = create_family(generations - 1);
    p->parents[1] = create_family(generations - 1);

    // Randomly assign alleles: one from each parent
    int idx0 = rand() % 2;
    int idx1 = rand() % 2;
    p->alleles[0] = p->parents[0]->alleles[idx0];
    p->alleles[1] = p->parents[1]->alleles[idx1];

    return p;
}

void print_family(person *p, int generation)
{
    if (p == NULL)
    {
        return;
    }

    // Indent according to generation
    for (int i = 0; i < generation * INDENT_LENGTH; i++)
    {
        printf(" ");
    }

    // Determine label for this generation
    if (generation == 0)
    {
        printf("Child (blood type %c%c)\n", p->alleles[0], p->alleles[1]);
    }
    else if (generation == 1)
    {
        printf("Parent (blood type %c%c)\n", p->alleles[0], p->alleles[1]);
    }
    else
    {
        // For generation >= 2, print "Great-" (generation - 2) times, then "Grandparent"
        for (int i = 0; i < generation - 2; i++)
        {
            printf("Great-");
        }
        printf("Grandparent (blood type %c%c)\n", p->alleles[0], p->alleles[1]);
    }

    // Print parents of the current person
    print_family(p->parents[0], generation + 1);
    print_family(p->parents[1], generation + 1);
}

void free_family(person *p)
{
    if (p == NULL)
    {
        return;
    }
    // Free parents recursively, then this person
    free_family(p->parents[0]);
    free_family(p->parents[1]);
    free(p);
}

char random_allele(void)
{
    int r = rand() % 3;
    switch (r)
    {
        case 0:
            return 'A';
        case 1:
            return 'B';
        default:
            return 'O';
    }
}
