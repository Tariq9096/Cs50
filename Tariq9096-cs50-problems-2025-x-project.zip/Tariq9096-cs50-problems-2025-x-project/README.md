# Flask To-Do List

**Project name:** Flask To-Do App
**Author:** <Tariq Ahmed (GitHub: [Tariq9096](https://github.com/Tariq9096))>
**Repo:** <https://github.com/Tariq9096/final_project>
**Live demo:** <https://fuzzy-capybara-v6wqqppjvjwvhwrpq-5000.app.github.dev/>
**Demo video (YouTube):** <https://youtu.be/XbUNfuBPNK8?feature=shared>

## Description
The Flask To-Do List project is a comprehensive web application designed to help users efficiently manage and organize their daily tasks. This project combines a user-friendly interface with robust backend functionality, offering a seamless experience for task management. Users can create, edit, complete, and delete tasks, all within a secure and interactive environment. By leveraging the Flask framework, this application demonstrates the practical application of full-stack web development principles, including routing, template rendering, database management, and user authentication.

The main goal of this project is to provide a tool that enhances productivity and task organization. Many individuals struggle to keep track of their daily responsibilities, deadlines, and personal projects. This application addresses that challenge by offering a centralized platform where all tasks are stored and easily accessible. Upon registering, each user is given a personal account, ensuring that their tasks are private and securely stored in an SQLite database. This database integration allows for persistent storage, meaning tasks remain available even after closing the application or restarting the server.

The user interface is designed with simplicity and accessibility in mind. HTML and CSS are used to create a responsive design that works across multiple devices, including desktops, tablets, and mobile phones. Navigation is intuitive, and users can quickly locate key features such as adding new tasks, marking tasks as complete, or editing existing tasks. Form validation is implemented to prevent errors, such as submitting empty tasks, and error messages are displayed in a clear and helpful manner. This ensures a smooth and frustration-free user experience.

From a technical standpoint, the project showcases essential backend functionalities. Flask’s routing system is used to handle multiple pages and endpoints, allowing users to interact with the application without unnecessary page reloads. The Jinja2 templating engine is used to dynamically render HTML pages based on database content. This enables the application to display user-specific tasks and updates in real-time. Session management is also implemented to maintain login states, ensuring that users can securely access their personal tasks while keeping data private from others.

Developing this project involved several learning opportunities and challenges. One major challenge was implementing secure user authentication, which required understanding hashing techniques and proper session handling. Another was managing the flow of data between the frontend and backend while keeping the code organized and maintainable. By overcoming these challenges, I gained a deeper understanding of web application architecture, database interactions, and responsive design principles. These skills are directly applicable to real-world web development scenarios, making this project a valuable learning experience.

The Flask To-Do List is highly extensible. In the future, additional features could be implemented to further enhance its usability and functionality. These could include task categories, priority levels, due dates with reminders, drag-and-drop reordering of tasks, and even integration with external calendar applications. Each of these improvements would increase the application’s usefulness while providing opportunities to explore more advanced web development concepts.

Overall, this project demonstrates the successful integration of frontend and backend technologies into a cohesive application. It provides a practical solution for task management while showcasing the developer’s ability to design, build, and deploy a functional web application. The Flask To-Do List project emphasizes usability, security, and maintainability, offering a solid example of what can be achieved through careful planning, coding, and problem-solving.

## Project Overview
The **Flask To-Do List** is a web application built using Python's Flask framework. It allows users to create, manage, and track their daily tasks in an organized and efficient way. This project was designed to practice full-stack web development skills and to demonstrate the ability to build a functional, interactive, and user-friendly web application from scratch. Users can register accounts, log in securely, add tasks, mark tasks as completed, edit existing tasks, and delete tasks that are no longer needed. The app is lightweight, responsive, and intuitive, making it suitable for everyday personal or academic task management.

## Motivation
The primary motivation behind this project was to develop a practical application that integrates backend functionality with a clean, interactive frontend. Many people struggle to stay organized and manage their tasks effectively. By building this To-Do List, I aimed to create a tool that helps users manage their responsibilities while simultaneously enhancing my understanding of Flask, HTML, CSS, and database management. This project also serves as a demonstration of my ability to handle user authentication, form submissions, and dynamic content rendering.

## How to Run
1. **Install Dependencies:**
   Make sure Python and Flask are installed. You can install Flask with:
   ```bash
   pip install Flask
