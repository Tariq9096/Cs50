#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>

#define BLOCK 512

// Helper to detect JPEG header
bool is_jpeg_header(const uint8_t *b)
{
    return b[0] == 0xff && b[1] == 0xd8 && b[2] == 0xff && (b[3] & 0xf0) == 0xe0;
}

int main(int argc, char *argv[])
{
    if (argc != 2)
    {
        printf("Usage: ./recover IMAGE\n");
        return 1;
    }

    FILE *in = fopen(argv[1], "rb");
    if (in == NULL)
    {
        printf("Could not open file.\n");
        return 1;
    }

    uint8_t buffer[BLOCK];
    FILE *out = NULL;
    int jpg_count = 0;
    char filename[8]; // "000.jpg" + '\0'

    while (fread(buffer, 1, BLOCK, in) == BLOCK)
    {
        if (is_jpeg_header(buffer))
        {
            // If already writing a JPEG, close it
            if (out != NULL)
            {
                fclose(out);
            }

            // Make a new filename
            sprintf(filename, "%03i.jpg", jpg_count);
            out = fopen(filename, "wb");
            if (out == NULL)
            {
                printf("Could not create file.\n");
                fclose(in);
                return 1;
            }
            jpg_count++;
        }

        // If we’re currently writing, write the block
        if (out != NULL)
        {
            fwrite(buffer, 1, BLOCK, out);
        }
    }

    if (out != NULL)
    {
        fclose(out);
    }
    fclose(in);

    return 0;
}
