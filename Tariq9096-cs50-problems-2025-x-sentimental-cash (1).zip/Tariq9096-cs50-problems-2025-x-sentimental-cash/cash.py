def main():
    while True:
        try:
            cents = float(input("Change owed: "))
            if cents >= 0:
                break
        except ValueError:
            continue

    cents = round(cents * 100)

    coins = 0
    for coin in [25, 10, 5, 1]:
        coins += cents // coin
        cents %= coin

    print(coins)


if __name__ == "__main__":
    main()
