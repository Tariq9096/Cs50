import sys
import csv

def main():
    # Check usage
    if len(sys.argv) != 3:
        print("Usage: python dna.py data.csv sequence.txt")
        sys.exit(1)

    database_path = sys.argv[1]
    sequence_path = sys.argv[2]

    # Read database
    people = []
    with open(database_path, newline="") as f:
        reader = csv.DictReader(f)
        strs = reader.fieldnames[1:]  # skip "name"
        for row in reader:
            # convert STR counts to int
            for s in strs:
                row[s] = int(row[s])
            people.append(row)

    # Read DNA sequence
    with open(sequence_path, "r") as f:
        sequence = f.read().strip()

    # Compute longest runs for each STR in the sequence
    profile = {s: longest_match(sequence, s) for s in strs}

    # Compare against each person
    for person in people:
        if all(person[s] == profile[s] for s in strs):
            print(person["name"])
            return

    print("No match")


def longest_match(sequence, subseq):
    """
    Returns length of the longest run of 'subseq' in 'sequence'.
    """
    longest = 0
    m, n = len(sequence), len(subseq)

    for i in range(m - n + 1):
        count = 0
        # keep moving forward in chunks of subseq if they match
        while sequence[i + count*n : i + (count+1)*n] == subseq:
            count += 1
        if count > longest:
            longest = count
    return longest


if __name__ == "__main__":
    main()
