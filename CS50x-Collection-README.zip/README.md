# CS50x Collection

This repository contains all my problem sets and projects from Harvard's CS50x course.  
Each week is organized into a separate folder.  

## Folder Structure
- Week0 - Scratch
- Week1 - C
- Week2 - Arrays
- Week3 - Algorithms
- Week4 - Memory
- Week5 - Data Structures
- Week6 - Python
- Week7 - SQL
- Week8 - HTML, CSS, JS
- Week9 - Flask
- Week10 - Final Project

---
This repo serves as a complete archive of my CS50x journey.
