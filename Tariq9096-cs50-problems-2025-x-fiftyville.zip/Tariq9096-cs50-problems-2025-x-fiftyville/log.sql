-- Keep a log of any SQL queries you execute as you solve the mystery.

-- 1. Confirm crime details (time & location)
SELECT description
FROM crime_scene_reports
WHERE year = 2024 AND month = 7 AND day = 28
  AND street = 'Humphrey Street';

-- 2. Interviews mentioning the crime scene
SELECT name, transcript
FROM interviews
WHERE year = 2024 AND month = 7 AND day = 28
  AND transcript LIKE '%bakery%';

-- 3. Security logs—cars leaving parking lot 10:15–10:25
SELECT people.name
FROM bakery_security_logs
JOIN people ON bakery_security_logs.license_plate = people.license_plate
WHERE year = 2024 AND month = 7 AND day = 28
  AND hour = 10 AND minute BETWEEN 15 AND 25
  AND activity = 'exit';

-- 4. ATM withdrawals at Leggett or Fifer Street
SELECT people.name
FROM atm_transactions
JOIN bank_accounts ON atm_transactions.account_number = bank_accounts.account_number
JOIN people ON bank_accounts.person_id = people.id
WHERE year = 2024 AND month = 7 AND day = 28
  AND atm_location = 'Leggett Street'
  AND transaction_type = 'withdraw';

-- 5. Phone calls under 60 seconds on crime day
SELECT caller, receiver
FROM phone_calls
WHERE year = 2024 AND month = 7 AND day = 28
  AND duration < 60;

-- 6. Earliest flight out on July 29
SELECT id
FROM flights
WHERE year = 2024 AND month = 7 AND day = 29
ORDER BY hour, minute ASC
LIMIT 1;

-- 7. Those on that earliest flight
SELECT people.name
FROM passengers
JOIN people ON passengers.passport_number = people.passport_number
WHERE flight_id = (/* flight id from query 6 */);

-- 8. Destination city of that flight
SELECT city
FROM airports
WHERE id = (
  SELECT destination_airport_id
  FROM flights
  WHERE id = (/* same flight id from query 6 */)
);

-- 9. Who was called by the thief (accomplice)?
SELECT people.name
FROM people
WHERE phone_number IN (
  SELECT receiver
  FROM phone_calls
  WHERE year = 2024 AND month = 7 AND day = 28
    AND duration < 60
    AND caller = (
      SELECT phone_number
      FROM people
      WHERE name = '<thief-name-found>'
    )
);
