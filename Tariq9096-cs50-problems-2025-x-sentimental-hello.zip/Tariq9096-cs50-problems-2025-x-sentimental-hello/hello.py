name = input("what is your name? ")
print (f"hello, {name}")
