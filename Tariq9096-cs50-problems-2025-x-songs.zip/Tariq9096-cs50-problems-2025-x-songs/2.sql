SELECT name FROM songs ORDER BY tempo ASC;
