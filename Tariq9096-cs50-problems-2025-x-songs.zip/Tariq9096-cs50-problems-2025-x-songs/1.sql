SELECT name FROM songs;

