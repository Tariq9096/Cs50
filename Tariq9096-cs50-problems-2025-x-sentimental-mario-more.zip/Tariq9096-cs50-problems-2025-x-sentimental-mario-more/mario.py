def main():
    while True:
        try:
            n = int(input("Height: "))
            if 1 <= n <= 8:
                break
        except ValueError:
            continue

    for i in range(1, n + 1):
        # Left spaces
        print(" " * (n - i), end="")
        # Left blocks
        print("#" * i, end="")
        # Gap
        print("  ", end="")
        # Right blocks
        print("#" * i)


if __name__ == "__main__":
    main()
